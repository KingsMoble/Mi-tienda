
import { useState } from 'react';

const productos = [
  {
    id: 1,
    nombre: 'iPhone 14 Pro',
    descripcion: 'Pantalla Super Retina XDR, cámara de 48 MP, chip A16 Bionic.',
    precio: '$1,100',
    imagen: 'https://via.placeholder.com/200x200?text=iPhone+14+Pro'
  },
  {
    id: 2,
    nombre: 'PlayStation 5',
    descripcion: 'Gráficos 4K, disco SSD ultra rápido.',
    precio: '$600',
    imagen: 'https://via.placeholder.com/200x200?text=PS5'
  },
  {
    id: 3,
    nombre: 'Samsung Galaxy S23',
    descripcion: 'Pantalla AMOLED dinámica de 120Hz, cámara triple.',
    precio: '$950',
    imagen: 'https://via.placeholder.com/200x200?text=Galaxy+S23'
  }
];

function App() {
  const [carrito, setCarrito] = useState([]);

  const agregarAlCarrito = (producto) => {
    setCarrito([...carrito, producto]);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-6">Tienda Kingsmobile</h1>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {productos.map((p) => (
          <div key={p.id} className="bg-white p-4 rounded-xl shadow">
            <img src={p.imagen} alt={p.nombre} className="w-full h-48 object-cover rounded" />
            <h2 className="text-xl font-semibold mt-2">{p.nombre}</h2>
            <p className="text-gray-600 text-sm">{p.descripcion}</p>
            <p className="text-lg font-bold my-2">{p.precio}</p>
            <button onClick={() => agregarAlCarrito(p)} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Agregar al carrito</button>
          </div>
        ))}
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-3">Carrito de compras</h2>
        {carrito.length === 0 ? (
          <p className="text-gray-500">Tu carrito está vacío.</p>
        ) : (
          <ul className="space-y-2">
            {carrito.map((item, idx) => (
              <li key={idx} className="border-b pb-2">{item.nombre} - {item.precio}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default App;
